import SwiftUI

@main
struct MyApp: App {
        @State var identifier = "zh"
    var body: some Scene {
        WindowGroup {
            ContentView(identifier: $identifier)
                .environment(\.locale, .init(identifier: identifier))
        }
    }
}
