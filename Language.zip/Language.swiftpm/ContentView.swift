import SwiftUI

struct ContentView: View {
    @Environment(\.locale) var locale
    var languageCode: String? {locale.language.languageCode?.identifier}
    var isChineseLanguage: Bool { languageCode == "zh"}
    @Binding var identifier: String
    @AppStorage(" ") var IDshow = false
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            if isChineseLanguage {
                Text("你好，世界！")
            } else {
                Text("Hello, world!")
            }
            
            HStack{
                if IDshow {
                    Text("")
                        .onAppear(perform: {
                            identifier = "en"
                        })
                    Button("En", action: {
                        self.identifier = "zh"
                        self.IDshow.toggle()
                    })
                    .foregroundColor(Color.red)
                    .cornerRadius(15)
                } else {
                    Button("中", action: {
                        self.identifier = "en"
                        self.IDshow.toggle()
                    })
                    .foregroundColor(Color.red)
                    .cornerRadius(15)
                }
            }
            
        }
    }
}
